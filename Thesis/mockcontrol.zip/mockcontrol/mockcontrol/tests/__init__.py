"""Тесты MockControl."""
